package vtc.game.app.vcoin.vtcpay.utils;

/**
 * Created by ThuyChi on 9/16/2016.
 */
public class Const {
    public static int UI_CURRENT_CONTEXT = 0;
    public static final int UI_GAMELIST = 1;
    public static final int UI_HISTORY = 2;
    public static final int UI_NOTI = 3;
    public static final int UI_GIFTCODE = 4;
    public static final int UI_PROFILE = 5;
    public static final int UI_NEWS = 6;
    public static final int UI_GAME_INFO = 7;
    public static final int UI_NEWS_DETAIL = 8;
    public static final int UI_SHARE_GIFTCODE = 9;
    public static final int UI_EDIT_PROFILE = 10;
    public static final int UI_EDIT_PROFILE_CHANGE_PASSWORD = 11;
    public static final int UI_SEARCH = 12;
    public static final int UI_GUIDE = 13;
    public static final int UI_PROFILE_ACCOUNT = 14;
    public static final int UI_ACCOUNT_VERIFY = 15;
    public static final int UI_ACCOUNT_SECURITY = 16;
    public static final int UI_TAB_SMS_PLUS = 17;
    public static final int UI_TAB_LOGIN_SECURITY = 18;
    public static final int UI_TAB_CHANGE_PASSWORD = 19;
    public static final int UI_TAB_FREEZE_VCOIN = 20;
public static final int UI_TAB_SECRET_QUESTION = 21;

    public static final int FUNC_PHONE_VERIFY = 1;
    public static final int FUNC_EMAIL_EDIT = 2;
    public static final int FUNC_EMAIL_VERIFY = 3;
    public static final int FUNC_PHONE_EDIT = 4;
    public static final int FUNC_PHONE_REMOVE = 5;

    public static int RECYCLERVIEW_SMOOTH = 300;

    public static final int INDEX_ACTION_GAME_LIST = 0;
    public static final int INDEX_ACTION_GIFT_CODE = 1;
    public static final int INDEX_ACTION_SPINNING = 2;
    public static final int INDEX_ACTION_NEWS = 3;
    public static final int INDEX_ACTION_PROFILE = 4;

    public static final int COUNT_VIEW = 5;

    public static final int IMAGE_CORNER_RADIUS = 30;

    public static final int REQUEST_CODE_LOGIN = 101;
    public static final int REQUEST_CODE_RESGISTER = 102;
    public static final int REQUEST_CODE_SHARE_FB = 103;


    public static final int TYPE_MISSION_SHARE_FB = 1;
    public static final int TYPE_MISSION_DOWNLOAD = 0;

    public static final int OS_TYPE = 2;

    public static final int MAX_TIME_SPINNING = 43200000;

    public static final int GAME_STATUS_NEW = 0;
    public static final int GAME_STATUS_NORMAL = 1;
    public static final int GAME_STATUS_HOT = 2;

    public static final int BACKGROUND_ALPHA_VALUE = 50;
    public static final int BACKGROUND_ALPHA_FULL = 255;

    public static int DISPLAY_WIDTH = 0;
    public static int DISPLAY_HEIGHT = 0;

    public static final int ALERT_CLOSE = 0;
    public static final int ALERT_HOME = 1;
    public static final int ALERT_DONE = 2;
    public static final int ALERT_UPDATE_VCOIN = 3;

    public static Boolean HIDE_DOWNLOAD_BUTTON = false;

    public static int PHONE_NUMBER_IS_ACTIVED = 0; // 0 is not active, 1 is active
    public static int EMAIL_IS_ACTIVED = 0; // 0 is not active, 1 is active

    public static int TAB_ACCOUNT_INFOR = 0; // 0 is hide, 1 is show
    public static int TAB_ACCOUNT_SECURITY = 0; // 0 is hide, 1 is show
    public static int TAB_ACCOUNT_SUPPORT = 0; // 0 is hide, 1 is show
    public static int ACCOUNT_EDIT_PHONE_NO = 0; // 0 is hide, 1 is show
    public static int ACCOUNT_REMOVE_PHONE_NO = 0; // 0 is hide, 1 is show
    public static int ACCOUNT_VERIFY_PHONE_NO = 0; // 0 is hide, 1 is show
    public static int ACCOUNT_EDIT_EMAIL = 0; // 0 is hide, 1 is show
    public static int TAB_SMS_PLUS = 0; // 0 is hide, 1 is show
    public static int TAB_LOGIN_SECURITY = 0; // 0 is hide, 1 is show
    public static int TAB_EDIT_PASSWORD = 0; // 0 is hide, 1 is show
    public static int TAB_FREEZE_VCOIN = 0; // 0 is hide, 1 is show
    public static int TAB_EDIT_SECRET_QUESTION = 0; // 0 is hide, 1 is show
    public static int ACCOUNT_INFOR_PHONE_NO = 0; // 0 is hide, 1 is show
    public static int ACCOUNT_INFOR_EMAIL = 0; // 0 is hide, 1 is show

    public static int SHOW_VALUE = 1;
    public static int HIDE_VALUE = 0;

    public static final int SMS_PLUS_ACCESS_SERVICE = 1;
    public static final int SMS_PLUS_ADS = 2;
    public static final int SMS_PLUS_ACTIVE = 3;
    public static final int SMS_PLUS_PAY_SERVICE = 4;
    public static final int SMS_PLUS_OTP_SERVICE = 5;
    public static final int SMS_PLUS_ODP_SERVICE = 6;
    public static final int SMS_PLUS_ACCOUNT_SERVICE = 7;
    public static final int SMS_PLUS_ACCOUNT_OTP_LOGIN_SERVICE = 8;

}
