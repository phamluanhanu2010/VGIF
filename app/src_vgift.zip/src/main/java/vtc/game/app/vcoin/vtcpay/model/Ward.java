package vtc.game.app.vcoin.vtcpay.model;

/**
 * Created by LuanPV on 3/9/2017.
 */

public class Ward {
    private int wardId;
    private String wardName;

    public int getWardId() {
        return wardId;
    }

    public void setWardId(int wardId) {
        this.wardId = wardId;
    }

    public String getWardName() {
        return wardName;
    }

    public void setWardName(String wardName) {
        this.wardName = wardName;
    }

    public Ward() {
    }

    public Ward(String wardName, int wardId) {
        this.wardId = wardId;
        this.wardName = wardName;
    }



    /**
     * Pay attention here, you have to override the toString method as the
     * ArrayAdapter will reads the toString of the given object for the name
     *
     * @return locationName
     */
    @Override
    public String toString() {
        return wardName;
    }


}


