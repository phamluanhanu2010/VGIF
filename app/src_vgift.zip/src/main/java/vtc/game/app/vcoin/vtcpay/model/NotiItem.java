package vtc.game.app.vcoin.vtcpay.model;

import java.io.Serializable;

/**
 * Created by ThuyChi on 9/21/2016.
 */
public class NotiItem implements Serializable {
    public String notiID;
    public String notiTitle;
    public boolean isOpen;
    public long createTime;
    public String pictureUrl;
    public boolean isAutoNoti;

    public boolean isAutoNoti() {
        return isAutoNoti;
    }

    public void setAutoNoti(boolean autoNoti) {
        isAutoNoti = autoNoti;
    }

    public boolean isOpen() {
        return isOpen;
    }

    public void setOpen(boolean open) {
        isOpen = open;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public int notiType;
    public String link;

    public String getNotiID() {
        return notiID;
    }

    public void setNotiID(String notiID) {
        this.notiID = notiID;
    }

    public String getNotiTitle() {
        return notiTitle;
    }

    public void setNotiTitle(String notiTitle) {
        this.notiTitle = notiTitle;
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }

    public int getNotiType() {
        return notiType;
    }

    public void setNotiType(int notiType) {
        this.notiType = notiType;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
