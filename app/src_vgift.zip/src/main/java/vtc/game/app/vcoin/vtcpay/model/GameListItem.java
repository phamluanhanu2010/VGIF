package vtc.game.app.vcoin.vtcpay.model;

import java.io.Serializable;

/**
 * Created by ThuyChi on 9/28/2016.
 */
public class GameListItem implements Serializable {
    private String content;
    private String gameID;
    private String gameName;
    private String pictureUrl;
    public Boolean borderFlag = false;

    public Boolean getBorderFlag() {
        return borderFlag;
    }

    public void setBorderFlag(Boolean borderFlag) {
        this.borderFlag = borderFlag;
    }

    public String getGameID() {
        return gameID;
    }

    public void setGameID(String gameID) {
        this.gameID = gameID;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
